package instawork;
 
import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
 
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
 
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
 
public class multibrowser {
 
	public WebDriver driver;
	
    
 
  @Parameters("browser")
 
  @BeforeClass
  public void beforeTest(String browser) throws InterruptedException {
	  
  if(browser.equalsIgnoreCase("firefox"))
  {
	  String Filepath = System.getProperty("user.dir") + "\\src\\drivers\\geckodriver.exe";
	  System.setProperty("webdriver.gecko.driver", Filepath);
	  System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE,"true");
	  System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE,"C:\\temp\\logs.txt");
	  driver = new FirefoxDriver();
  }
  
  else if (browser.equalsIgnoreCase("chrome")) 
  { 
	  String Filepath = System.getProperty("user.dir") + "\\src\\drivers\\chromedriver.exe";
	  System.setProperty("webdriver.chrome.driver", Filepath);
 
	  driver = new ChromeDriver();
	  ChromeOptions options = new ChromeOptions();
	  options.addArguments("--disable-extensions");
	  
  } 
    
  	driver.manage().window().maximize();
  	driver.get("https://www.google.com");
  	
	Thread.sleep(3000);
  
  }

  

@Test 
public void googlesearch() throws InterruptedException {
	
	
	String searchterm = "instawork";
	String matchingURL = "https://www.instawork.com";
driver.findElement(By.id("lst-ib")).click();
	
	driver.findElement(By.id("lst-ib")).sendKeys(searchterm);
	Thread.sleep(3000);
	
	driver.findElement(By.id("lst-ib")).sendKeys(Keys.ENTER);
	Thread.sleep(3000);
	
	int pagenumber = 0;
	boolean foundmatch = false;
	String foundmatchingurl = "";
	
	while(!foundmatch)
	{
		
		pagenumber++;
		
		WebElement nextlink = (new WebDriverWait(driver, 10))
	            .until(ExpectedConditions.elementToBeClickable(By.cssSelector("a#pnnext")));
		
		
		
	            List<WebElement> a = driver.findElements(By.cssSelector("h3.r>a"));
		
		
		for(WebElement element : a)
		{
			
			String href = element.getAttribute("href");
			String title = element.getText();
		
			if(href.contains(matchingURL))
			{
				System.out.println("the matching url found is :" + href);
				System.out.println("Matching url found at page number :" + pagenumber  );
				 
				foundmatchingurl = href;
				foundmatch =true;
				
				int b = href.indexOf(href);
				 System.out.println("index of found result is : " + b);
				 
				 try{
				 if(b == 0)
				 {
					 System.out.println("the searched keyword is displayed first in google search result");
					 
				 }
				 
				 else
				 {
					 System.out.println("the searched eyword is not displayed at first, instead displayed at " + b + "position");
				 }
			}catch (Throwable t)
				 
			     {
			
			       t.printStackTrace();
			
			     }

			}
			
		
		}
		nextlink = (new WebDriverWait(driver, 10))
	            .until(ExpectedConditions.elementToBeClickable(By.cssSelector("a#pnnext")));
		
		nextlink.click();
	}
	
	}
	
@AfterClass public void afterTest() {
	 
	driver.quit();

}

	
	
}
			

	
	
	
	



